﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace GuessTheCountry
{
    public class Game
    {

        public void StartGame()
        {
            Console.WriteLine("Welcome to the game Guess the Country!");
            Console.WriteLine("This is a trivia game where you can test your geographical knowledge");
            Console.WriteLine("Please press any key to start");
            Console.ReadKey();
            Questions();
        }

        public void Questions()
        {
            string input = "";
            string Name = "";

            Console.WriteLine("Please enter your name");
            Name = Console.ReadLine();
            Console.WriteLine("Hello " + Name);
            Console.ReadKey();
            Console.WriteLine("Let's do an easy test");
            Console.WriteLine("How many countries are in the world?");
            Console.WriteLine("a) 181 b) 195 c)260");
            input = Console.ReadLine();
            if(input == "b")
            {
                Console.WriteLine("Correct! There are 195 countries in the world in the year 2024");
            }
            else
            {
                Console.WriteLine("Inorrect! There are 195 countries in the world in the year 2024. Now you know");
            }
            Console.ReadKey();

            Console.WriteLine("Which country is the richest in the world?");
            Console.WriteLine("a) Luxemborg b) Singapure c)Qatar");
            input = Console.ReadLine();
            if (input == "a")
            {
                Console.WriteLine("Correct! The richest country in the world is Luxemborg in the year 2024");
            }
            else
            {
                Console.WriteLine("Inorrect! The richest country in the world is Luxemborg in the year 2024. Now you know");
            }
            Console.ReadKey();

            Console.WriteLine("Last question! Which country is the largest in the world?");
            Console.WriteLine("a) Russia b) China c)United States");
            input = Console.ReadLine();
            if (input == "a")
            {
                Console.WriteLine("Correct! The largest country in the world is Russia in the year 2024");
            }
            else
            {
                Console.WriteLine("Inorrect! The largest country in the world is Russia in the year 2024. Now you know");
            }
            Console.ReadKey();


            Console.WriteLine("Thank you for playing!");
            Console.WriteLine("Please press any key to exit");
            Console.ReadKey();
        }
    }
}
