﻿namespace GuessTheCountry
{
    class Program
    {
        static public Game guessthecountry = new Game();
        static void Main(string[] args)
            {
                Console.Title = "Guess the Country";
                guessthecountry.StartGame();
            }
        
    }
}