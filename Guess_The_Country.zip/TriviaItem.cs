﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuessTheCountry
{
    class TriviaItem
    {
        private string Question;
        private string Answer;

        public TriviaItem(string TriviaQuestion, string TriviaAnswer)
        {
            Question = TriviaQuestion;
            Answer = TriviaAnswer;
        }


    }
}
