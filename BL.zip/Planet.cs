﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueLight
{
    public class Planet
    {
        public string name;
        public int ID;

        //In red planet time to steal
        //Make sure the window is red color 
        public static void DowntownMarket()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            string input = "";

            while (true)
            {
                Console.WriteLine("You have entered the downtown market! Now it's time to find a victim");
                Console.WriteLine("Remember they're used to thieves. Be careful!");
                Console.WriteLine("There is a seller who left his backapck unattended and a buyer who has money sticking out of his pocket");
                Console.WriteLine("If you'd like to steal money from the seller type a, if you want to steal from the buyer type b");
                input = Console.ReadLine();

                if (input == "a")
                {
                    Console.WriteLine("Oh no! You been caught!");
                    Console.WriteLine("Please choose your punishment");
                    Console.WriteLine("If you want to loose a hand type a, if you want to loose a leg type b");
                    Console.ReadLine();
                    Console.ResetColor();
                    Console.WriteLine("Just kidding you lost!");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    break;

                }

                else if (input == "b")
                {
                    //call victim money
                    Victim buyer = new Victim();
                    Program.bluelight.Bandit.AddMoney(buyer.steal());
                    Console.WriteLine("It's time to steal some food");
                    Program.bluelight.WaitUser();
                    FOODMARKET();
                    //let player now start list
                    break;
                }

                else
                {
                    Console.WriteLine("You have to type a or b. Choose one. It's to late to not steal money.");
                    Console.WriteLine("Embrace the crime!");

                }
            }

        }

        public static void FOODMARKET()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            string input = "";
            Console.WriteLine("There's a stand with different types of food. Go steal the following: coffee, bag of apples and mangos, bread and meat");
            Console.WriteLine("If you'd like to steal the food type a, if not type b");
            input = Console.ReadLine();
            if (input == "a")
            {
                Program.bluelight.Bandit.inventory.Add("coffee");
                Program.bluelight.Bandit.inventory.Add("bag of apples and mangos");
                Program.bluelight.Bandit.inventory.Add("bread");
                Program.bluelight.Bandit.inventory.Add("meat");

                for (int i = 0; i < Program.bluelight.Bandit.inventory.Count(); i++)
                {
                    Console.WriteLine($"You stole {Program.bluelight.Bandit.inventory[i]}");
                }

                Program.bluelight.WaitUser();
                Console.WriteLine("If you have time there's also an artist looking away from her paint. You can steal it too");
                Console.WriteLine("If you'd like to steal the paint type a, if not type b");
                input = Console.ReadLine();
                if (input == "a")
                {
                    Program.bluelight.Bandit.inventory.Add("paint");
                    Console.WriteLine($"You stole {Program.bluelight.Bandit.inventory[4]}");
                    Console.WriteLine("Congratulations you have completed your mission!");
                    Console.ResetColor();
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Congratulations you have completed your mission!");
                    Console.ResetColor();
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                }

            }

            else
            {
                Console.ResetColor();
                Console.WriteLine("We do not support honest people here. Loser!");
                Console.WriteLine("Press any key to exit the game");
                Console.ReadKey();
            }

        }

        //Blue Planet
        public static void InTheHeart()
        {
            Console.BackgroundColor = ConsoleColor.Cyan;
            string input;

            Console.WriteLine("You have started your journey to the heart of the Island! The path is full of fruits");
            Console.WriteLine("Please press enter to collect as many fruits as you can");
            Console.ReadKey();
            Program.bluelight.Bandit.inventory.Add("Mango");
            Program.bluelight.Bandit.inventory.Add("Banana");
            Program.bluelight.Bandit.inventory.Add("Coconut");
            Program.bluelight.Bandit.inventory.Add("Mamey");
            Program.bluelight.Bandit.inventory.Add("Papaya");

            for (int i = 0; i < Program.bluelight.Bandit.inventory.Count(); i++)
            {
                Console.WriteLine($"You have collected {Program.bluelight.Bandit.inventory[i]}");
            }

            Program.bluelight.WaitUser();
            Console.WriteLine("After collecting lots of fruit you have arrived to a beautiful waterfall");
            Console.WriteLine("This is the heart of the island!");
            Program.bluelight.WaitUser();
            Console.WriteLine("Inside the water you can see 10 pounds of gold");
            Console.WriteLine("Please press enter to collect the gold");
            Console.ReadKey();
            Program.bluelight.Bandit.inventory.Add("10 pounds of gold");
            Program.bluelight.WaitUser();
            Console.WriteLine("A wizard from the green planet has appeared in the other side of the waterfall");
            Program.bluelight.WaitUser();
            Console.WriteLine("Kuma! Is that you? Hey!");
            Console.WriteLine("true or false?");
            input = Console.ReadLine();

            bool wizardanswer = true;
            if (input == "true")
            {
                wizardanswer = true;
            }
            else if (input == "false")
            {
                wizardanswer = false;
            }


            if (wizardanswer == true)
            {
                Console.WriteLine("My sweet friend! Here is some extra gold for you");
                Program.bluelight.Bandit.inventory.Add("5 extra pounds of gold");
                Program.bluelight.WaitUser();
                Console.WriteLine("Congratulations you have completed your mission!");
                Console.ResetColor();
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
            }

            else
            {
                Console.ResetColor();
                Console.WriteLine("The Wizard killed you!");
                Program.bluelight.WaitUser();
                Console.WriteLine("You got yourself killed. You lost.");
                Console.WriteLine("Press any key to exit the game");
                Console.ReadKey();

            }
        }

        //Cyber Planet
        public static void StealinMoney()
        {
            Console.BackgroundColor = ConsoleColor.Magenta;
            string input = "";

            Console.WriteLine("There is a business man who just got off his 9 to 5 about to walk by you.");
            Console.WriteLine("He just pushed an old lady out of his way, are you ready to steal his money? yes or no?");
            Console.WriteLine("If you'd like to the steal money type a, otherwise type b");
            input = Console.ReadLine();

            Random random = new Random();
            if (input == "a")
            {
                int randomScenario = random.Next(1, 3);
                switch (randomScenario)
                {
                    case 1:
                        Victim businessman = new Victim();
                        Program.bluelight.Bandit.AddMoney(businessman.steal());
                        Console.WriteLine("It's time to steal some food");
                        Program.bluelight.WaitUser();
                        GroceryStore();
                        break;

                    case 2:
                        Console.WriteLine("Oh no! He saw your intentions!");
                        Console.WriteLine("You got yourself caught!");
                        Program.bluelight.WaitUser();
                        Console.ResetColor();
                        Console.WriteLine("You lost!");
                        Console.WriteLine("Press any key to exit");
                        Console.ReadKey();
                        break;
                }


            }
            else
            {
                Console.WriteLine("You decided he may have an important title and it's not worth the risk");
                Console.WriteLine("However, he recognized you from the wanted poster.");
                Console.WriteLine("You got yourself caught!");
                Program.bluelight.WaitUser();
                Console.ResetColor();
                Console.WriteLine("You lost!");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
            }

        }

        private static void GroceryStore()
        {
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.WriteLine("It's been a long day.");
            Console.WriteLine("Take it easy");
            Program.bluelight.WaitUser();

            Random random = new Random();
            int randomCase = random.Next(1, 3);
            switch (randomCase)
            {
                case 1:
                    Console.WriteLine("There aren't too many people.");
                    Console.WriteLine("Please press enter to grab food carefully!");
                    Console.ReadKey();
                    Console.WriteLine("The cashier recognized you from the wanted poster on the TV screen!");
                    Console.WriteLine("You got yourself caught!");
                    Program.bluelight.WaitUser();
                    Console.ResetColor();
                    Console.WriteLine("You lost!");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    break;

                case 2:
                    Console.WriteLine("There aren't lots of people in the store.");
                    Console.WriteLine("Please be careful!");
                    Console.WriteLine("Please press enter to grab food carefully!");
                    Console.ReadKey();
                    Program.bluelight.Bandit.inventory.Add("Coffee");
                    Program.bluelight.Bandit.inventory.Add("Bread");
                    Program.bluelight.Bandit.inventory.Add("Oil");
                    Program.bluelight.Bandit.inventory.Add("Potatoes");
                    Program.bluelight.Bandit.inventory.Add("Eggs");
                    Program.bluelight.Bandit.inventory.Add("Eggplant");
                    Program.bluelight.Bandit.inventory.Add("Bag of Apples");
                    //Console.WriteLine($"You stole {Program.bluelight.Bandit.inventory[0]}");
                    for (int i = 0; i < Program.bluelight.Bandit.inventory.Count(); i++)
                    {
                        Console.WriteLine($"You have collected {Program.bluelight.Bandit.inventory[i]}");
                    }

                    Program.bluelight.WaitUser();
                    Console.WriteLine("After cautiously sneaking out you have completed your mission!");
                    Console.WriteLine("Congratulations!");
                    Console.ResetColor();
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    break;
            }
        }
    }

}


