﻿using System;
namespace BlueLight
{
    public class People
    {
        public int money;

        public People()
        {


        }
    }
}
