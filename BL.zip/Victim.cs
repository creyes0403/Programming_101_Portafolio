﻿using System;
namespace BlueLight
{
    public class Victim : People
    {
        public string name;
        public string food;


        public Victim()
        {
            money = 6000;
        }

        public int steal()
        {
            int profit = money;
            money = 0;
            return profit;
        }
    }
}
