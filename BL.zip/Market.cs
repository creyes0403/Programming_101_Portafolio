﻿using System;
namespace BlueLight
{
    public class Market
    {
        public string paintings;

        public Market()
        {


        }

        //make the window green
        void StartSelling()
        {
            Console.WriteLine("Open for business!");
        }

        public int SellArt()
        {
            int price = 0;
            string input = "";
            int limit = 0;
            Console.WriteLine("You are about to sell personal paintings that you worked on last week. It took you 80 hrs. How much would you like to sell them for? Enter #");
            input = Console.ReadLine();
            price = Int32.Parse(input);//bug issue

            Random number = new Random();
            limit = number.Next();

            if (price <= 5000)
            {
                return price;
            }

            else
            {
                Console.WriteLine("The price is too high. You need to eat. You tripping.");
                Console.WriteLine("Try Again");
            }

            return 0;

        }

    }
}
