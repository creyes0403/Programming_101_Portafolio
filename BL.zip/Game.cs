﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace BlueLight
{
    public class Game
    {

        // properties
        Planet P = new Planet();
        Planet R = new Planet();
        Planet B = new Planet();
        Planet C = new Planet();

        Planet CurrentPlanet;

        Flower Blue = new Flower();
        public Player Bandit = new Player();

        Market x = new Market();

        //constructor
        public Game()
        {
            P.name = "Home Planet";
            P.ID = 0;
            R.name = "Red Planet";
            R.ID = 1;
            B.name = "Blue Planet";
            B.ID = 2;
            C.name = "Cyber Planet";
            C.ID = 3;

            CurrentPlanet = P;

            Blue.color = "Blue Flower";
            Blue.type = "Magic";

            Bandit.Name = "Kuma";
            Bandit.Gender = "Nonbinary";
            Bandit.ZodiacSign = "Leo";
            Bandit.Color = "Brown & Green";
            Bandit.Race = "Earth Genasi";

        }

        //methods
        public void StartGame()
        {

            Console.WriteLine("Blue Light");
            Console.WriteLine("Welcome to the Green Planet!");
            Console.WriteLine("Here, we enjoy the fruits of our mother nature & travel anywhere we like to with the help of the blue flowers that light up in the darkness of the night.");
            Console.WriteLine("Please press any key to start");
            Console.ReadKey();
            PlayerName();
            Story();
            FirstChoice();
        }

        static void PlayerName()
        {
            string Name = "";
            Console.WriteLine("To explore the green planet, please name your character");
            Name = Console.ReadLine();
            Console.WriteLine("Hello " + Name);
            Console.ReadKey();
            Console.WriteLine("You have entered the body of a bandit known as Kuma");
            Console.WriteLine("They are an Earth Genasi who was abandoned by his mother at age of 7");
            Console.WriteLine("To survive they had to learn how to steal from people that live at the planets you can visit with the help of the blue flowers");
            Console.WriteLine("However, nowadays they only steal when needed since they started a business selling art a couple years ago");
            Console.WriteLine("Please press enter to continue");
            Console.ReadKey();

        }

        public void Story()
        {
            Console.WriteLine("You wake up in a cozy home that smells like coffee. You look at the clock, it's 12pm");
            Console.WriteLine("It seems like you were about to drink your morning coffee, but after eating your breakfast you accidentally took a nap on the couch");
            Console.WriteLine("You need to hurry up and go get more art supplies and food. Since you have $0 to your name you will have to steal");
            Console.ReadKey();
        }

        public void FirstChoice()
        {
            string input = "";
            Console.WriteLine("Are you ready to go on adventure? If yes please press a, if not press b");
            input = Console.ReadLine();

            //FOR PLANETS
            Random planetgenerator = new Random();

            if (input == "a")
            {
                Console.WriteLine("It's time to eat a blue flower to go to a new planet!");

                while (true)
                {
                    input = PromptUser("Please go ahead and type \"eat\"");
                    input = input.ToLower();

                    if (input.Equals("eat"))
                    {
                        break;
                    }

                    else
                    {
                        Console.WriteLine("Damn, you don't know how to type?! I said eat.");
                        WaitUser();
                    }
                }

                //Rafael helped me to figure out how to make this work:) The Randomization
                //randomize which planet will the player go to after eating the blue flower from planet 1 to less than 4 :)
                int SelectedPlanet = planetgenerator.Next(1, 4);
                switch (SelectedPlanet)
                {
                    case 1:
                        GoToPlanet(R);
                        break;
                    case 2:
                        GoToPlanet(B);
                        break;
                    case 3:
                        GoToPlanet(C);
                        break;
                }
            }
            else
            {
                Console.WriteLine("You may be running low, but it's a beautiful day outside, and you can travel to the other planets tomorrow.");
                Console.WriteLine("Please go ahead and type \"paint\"");
                Console.ReadLine();
                Console.ReadKey();
                GoToMarket();

                //take the character to sell paintings.
            }
        }

        public void GoToMarket()
        {
            string input = "";

            Console.WriteLine("You're at the biggest art market in downtown");
            Console.WriteLine("It's time to sell art!");
            WaitUser();
            Bandit.AddMoney(x.SellArt());
            Console.WriteLine("Would you like to keep selling art or would you like to go on an adventure? If you like to keep selling art type yes");
            input = Console.ReadLine();
            if (input == "yes")
            {
                GoToMarket();
            }
            else
            {
                FirstChoice();
            }

        }

        public void WaitUser()
        {
            //Wait for user inpout
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }

        public string PromptUser(string text)
        {
            Console.WriteLine(text);
            return Console.ReadLine();
        }

        public void GoToPlanet(Planet destination)
        {
            CurrentPlanet = destination;
            if (destination == R)
            {
                LandedOnPlanetR();
            }

            else if (destination == B)
            {
                LandedOnPlanetB();
            }

            else if (destination == C)
            {
                LandedOnPlanetC();
            }
        }


        //Make it red color the window
        public void LandedOnPlanetR()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Welcome to Red Planet!");
            //tell player what to do, and what to steal.
            Console.WriteLine("You have landed on the hottest planet. Here people do not have many resources.");
            Console.WriteLine("You will need to steal food from the market in downtown");
            Console.WriteLine("Press any key to go to the market in downtown");
            Console.ReadKey();
            Planet.DowntownMarket();
        }


        //Make it blue color the window
        public void LandedOnPlanetB()
        {
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Welcome to Blue Planet!");
            //tell player what to do, and what to collect.
            Console.WriteLine("You have landed on a deserted island. No need to steal today");
            Console.WriteLine("Find gold in the heart of the island and food on your way there");
            Console.WriteLine("Press any key to start your journey to the heart of the island");
            Console.ReadKey();
            Planet.InTheHeart();
        }


        //Make it purple the window
        public void LandedOnPlanetC()
        {
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Welcome to the Cyber Planet!");
            //tell player what to do, and what to steal.
            Console.WriteLine("You have landed on a big city. Full of resources and stores to steal food and money.");
            Console.WriteLine("Be aware that they have your name on the wanted list. Do not get caught!");
            Console.WriteLine("Press any key to start stealing");
            Console.ReadKey();
            Planet.StealinMoney();
        }


    }
}
