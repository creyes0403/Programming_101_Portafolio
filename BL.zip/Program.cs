﻿using System;
namespace BlueLight
{
    public class Program
    {
        static public Game bluelight = new Game();


        static void Main(string[] args)
        {
            Console.Title = "Blue Light";
            //Console.Read();

            bluelight.StartGame();

        }


    }

}
