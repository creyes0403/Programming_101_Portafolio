﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueLight
{
    public class Player : People
    {
        public string Name;
        public string Gender;
        public string ZodiacSign;
        public string Color;
        public string Race;

        public List<string> inventory = new List<string>();

        //Variable for bandits money


        public void Eat(Flower BL)
        {
            if (BL.color == "Blue")
            {

            }
        }

        public void AddMoney(int d)
        {
            money += d;
            Console.WriteLine("You now have $" + money);
        }

    }
}
