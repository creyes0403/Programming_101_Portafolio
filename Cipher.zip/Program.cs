﻿namespace Cipher
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Manipulating String Example: Simple Cipher";
            Message message = new Message();
        }
    }
}