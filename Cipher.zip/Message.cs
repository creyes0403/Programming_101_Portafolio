﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Cipher
{
     class Message
    {
        public Message()
        {
            WriteLine("Hello agent");
            Run();
        }

        private void Run()
        {

            Cipher cipher = new Cipher();
            string message;
            Clear();
            Write("Enter text: ");
            message = ReadLine();
            WriteLine(cipher.Encrypt(message));

            WriteLine("Press any key to continue...");
            ReadKey();
            Run();
        }
    }
}
