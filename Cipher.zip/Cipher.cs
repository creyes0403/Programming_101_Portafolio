﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cipher
{
    class Cipher
    {

        string alphabet;
        string substitute;

        public Cipher()
        {
            alphabet = "abcdefghijklmnopqrstuvwxyz";
            substitute = "opdefghiqrsxyzabcjklmntuvw";
        }

        public string Encrypt(string _message)
        {
            int index;
            char replacement = 'c';
            string result = "";
            _message = _message.ToLower();

            foreach (char c in _message)
            {
                Console.WriteLine('d');
                //add code here to replace each character c
                //with the letter from the same index number in the substitute string
            }

            return result;
        }

        public string Decrypt(string _message)
        {
            string result = "";
            return result;
        }
    }
}
