﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_A_Robot
{
    class Robot
    {
        public string Name;
        public string Color;

        public Robot(string name, string color)
        {
            Name = name;
            Color = color;
        }
    }
}
