﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_A_Robot
{
    class Player
    {
        public string Name;
        public Robot PlayerRobot;

        public Player()
        {
            PlayerRobot = new Robot("Robot Mach II", "Silver");
        }
    }
}
