﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyApplication
{
    public  class Player
    {
        public string Name;
        public int Points;

        public Player(string name)
        {
            Name = name;
            Points = 0;
        }
    }
}
