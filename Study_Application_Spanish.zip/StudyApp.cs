﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace StudyApplication
{
    
    public class StudyApp
    {
        public void Run()
        {
            string Name = "";

            WriteLine("Welcome to the Learning Spanish App");
            WriteLine("By Carolina Reyes");
            ReadKey();
            WriteLine("Please enter your name ");
            Name = ReadLine();
            Console.WriteLine("Hello " + Name);
            WriteLine("Let's start this study session");
            Console.ReadKey();
            Questions();
        }

        public void Questions()
        {
            string input = "";
  
            WriteLine("Flower in spanish is flor?");
            Console.WriteLine("true or false?");
            input = Console.ReadLine();

            bool flor = true;
            if (input == "true")
            {
                flor = true;
            }

            else if (input == "false")
            {
                flor = false;
            }


            if (flor == true)
            {
                Console.WriteLine("Correct! Flower in spanish is flor.");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                tree();

            }

            else
            {
                Console.WriteLine("Inorrect! Flower in spanish is flor.");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                tree();
            }
        }

        public void tree()
        {
            string input = "";

            WriteLine("Tree in spanish is raiz?");
            Console.WriteLine("true or false?");
            input = Console.ReadLine();

            bool raiz = true;
            if (input == "true")
            {
                raiz = true;
            }

            else if (input == "false")
            {
                raiz = false;
            }


            if (raiz == true)
            {
                Console.WriteLine("Incorrect.Raiz means root, not tree.");
                Console.WriteLine("Tree in spanish is arbol.");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                river();

            }

            else
            {
                Console.WriteLine("Correct! Tree in spanish is arbol.");
                Console.WriteLine("Raiz means root.");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                river();
            }
        }

        public void river()
        {
            string input = "";

            WriteLine("River in spanish is rio?");
            Console.WriteLine("true or false?");
            input = Console.ReadLine();

            bool rio = true;
            if (input == "true")
            {
                rio = true;
            }

            else if (input == "false")
            {
                rio = false;
            }


            if (rio == true)
            {
                Console.WriteLine("Correct! Rio in spanish is rio.");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                cloud();

            }

            else
            {
                Console.WriteLine("Inorrect! Rio in spanish is rio..");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                cloud();
            }
        }

        public void cloud()
        {
            string input = "";

            WriteLine("Cloud in spanish is sol?");
            Console.WriteLine("true or false?");
            input = Console.ReadLine();

            bool sol = true;
            if (input == "true")
            {
                sol = true;
            }

            else if (input == "false")
            {
                sol = false;
            }


            if (sol == true)
            {
                Console.WriteLine("Incorrect! Sol in spanish is sun, not cloud.");
                Console.WriteLine("Nube in spanish is cloud");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                done();

            }

            else
            {
                Console.WriteLine("Correct. Nube in spanish is cloud.");
                Console.WriteLine("Sol in spanish is sun");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                done();
            }
        }

        public void done()
        {
            Console.WriteLine("Thank you for studying with me!");
            Console.WriteLine("Have a great day!");

            //Display Score
        }

    }
}
