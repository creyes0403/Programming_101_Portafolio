﻿using System;
using static System.Console; 

namespace StudyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Title = "Learning Spanish";
            StudyApp app = new StudyApp();
            app.Run();
        }
    }
}